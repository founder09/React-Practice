import { useState } from "react";
import { v4 as uuidv4 } from 'uuid';

export default function TodoList() {
    let [todos,setTodos] = useState([{task:"sample",id:uuidv4()}]);
    let [newTodo,setNewTodo] = useState("");

    let addNewTask = ()=>{
        setTodos([...todos,{task:newTodo,id:uuidv4()}]);
        setNewTodo("");
    };

    let updateTaskValue=(event)=>{
         setNewTodo(event.target.value);
    }


  return (
    <div>
        <input type="text" placeholder="Add a task" value={newTodo} onChange={updateTaskValue}/>
        <br /><br />
        <button onClick={addNewTask}>Add task</button>
        <br /><br />   
        <hr />
      <h4>Task To DO</h4>
      <ul>
        {
            todos.map((todo)=>(
                <li key={todo.id}>{todo.task}</li>
            ))
        }
      </ul>
    </div>
  );
}
