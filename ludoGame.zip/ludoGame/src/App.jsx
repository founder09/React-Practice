import './App.css';
import TodoList from './TodoList';

function App() {
  return (
    <TodoList />
  );
}

export default App;
